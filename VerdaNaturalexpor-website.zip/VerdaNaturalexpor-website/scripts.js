// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add active class to navigation based on scroll
window.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('nav ul li a');
    
    let current = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        
        if (pageYOffset >= (sectionTop - 100)) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href').includes(current) || 
            (current === '' && link.getAttribute('href') === 'index.html')) {
            link.classList.add('active');
        }
    });
});

// Gallery filtering
document.addEventListener('DOMContentLoaded', function() {
    // Gallery filtering
    const filterBtns = document.querySelectorAll('.filter-btn');
    const galleryItems = document.querySelectorAll('.gallery-item');
    
    if (filterBtns.length > 0 && galleryItems.length > 0) {
        filterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                filterBtns.forEach(b => b.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                const filter = this.getAttribute('data-filter');
                
                galleryItems.forEach(item => {
                    if (filter === 'all' || item.getAttribute('data-category') === filter) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });
    }
    
    // Lightbox functionality
    const galleryItems = document.querySelectorAll('.gallery-item');
    const lightbox = document.getElementById('lightbox');
    
    if (galleryItems.length > 0 && lightbox) {
        const lightboxImg = document.getElementById('lightbox-img');
        const closeLightbox = document.querySelector('.close-lightbox');
        const lightboxCaption = document.querySelector('.lightbox-caption');
        
        galleryItems.forEach(item => {
            item.addEventListener('click', function() {
                const icon = this.querySelector('i').className;
                const caption = this.querySelector('h3').textContent;
                const description = this.querySelector('p').textContent;
                
                // In a real implementation, you would set the actual image
                // For now, we'll just show the icon
                lightboxImg.style.display = 'none';
                lightboxCaption.innerHTML = `<h3>${caption}</h3><p>${description}</p>`;
                lightbox.style.display = 'block';
                document.body.style.overflow = 'hidden';
            });
        });
        
        closeLightbox.addEventListener('click', function() {
            lightbox.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
        
        lightbox.addEventListener('click', function(e) {
            if (e.target === lightbox) {
                lightbox.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });
        
        // Close lightbox with ESC key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && lightbox.style.display === 'block') {
                lightbox.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        });
    }
});

// Form validation
function validateForm(form) {
    let isValid = true;
    const requiredFields = form.querySelectorAll('[required]');
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            isValid = false;
            field.style.borderColor = '#e74c3c';
            setTimeout(() => {
                field.style.borderColor = '#ddd';
            }, 3000);
        }
    });
    
    return isValid;
}

// Contact form submission
if (document.querySelector('.contact-form')) {
    document.querySelector('.contact-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateForm(this)) {
            // Here you would typically send the form data to your server
            // For now, we'll show a success message
            alert('Thank you for your message! We will contact you soon via WhatsApp or email.');
            this.reset();
        }
    });
}

// WhatsApp integration function
function openWhatsApp() {
    window.open('https://wa.me/6281229141609', '_blank');
}

// Instagram integration function
function openInstagram() {
    window.open('https://www.instagram.com/verdanaturalexports', '_blank');
}

// TikTok integration function
function openTikTok() {
    window.open('https://www.tiktok.com/@verda.natural.export', '_blank');
}

// Console message
console.log('VerdaNaturalEksport Website Loaded Successfully!');

// Auto-hide floating WhatsApp button on mobile when scrolling down
let lastScrollTop = 0;
const floatingBtn = document.querySelector('.floating-whatsapp');

if (floatingBtn) {
    window.addEventListener('scroll', function() {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > lastScrollTop && scrollTop > 100) {
            // Scrolling down
            floatingBtn.style.opacity = '0.5';
        } else {
            // Scrolling up
            floatingBtn.style.opacity = '1';
        }
        
        lastScrollTop = scrollTop;
    });
}